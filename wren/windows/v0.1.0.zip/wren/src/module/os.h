#ifndef process_h
#define process_h

#include "wren.h"

// Stores the command line arguments passed to the CLI.
void osSetArguments(int argc, const char* argv[]);

#endif
