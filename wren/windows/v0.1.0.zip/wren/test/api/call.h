#include "wren.h"

void callRunTests(WrenVM* vm);
