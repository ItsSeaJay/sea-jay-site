#include "wren.h"

void callWrenCallRootRunTests(WrenVM* vm);
