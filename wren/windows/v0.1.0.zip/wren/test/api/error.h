#include "wren.h"

WrenForeignMethodFn errorBindMethod(const char* signature);
