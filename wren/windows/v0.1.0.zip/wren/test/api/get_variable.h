#include "wren.h"

WrenForeignMethodFn getVariableBindMethod(const char* signature);
