#include "wren.h"

WrenForeignMethodFn handleBindMethod(const char* signature);
