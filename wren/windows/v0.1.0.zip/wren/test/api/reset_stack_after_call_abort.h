#include "wren.h"

void resetStackAfterCallAbortRunTests(WrenVM* vm);