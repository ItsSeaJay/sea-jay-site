# Building on windows

Building the `wren` project requires python2 to available in the path as `python`, in order to download and build the libuv dependency. The download and build of libuv is done as a pre-build step by the solution.
